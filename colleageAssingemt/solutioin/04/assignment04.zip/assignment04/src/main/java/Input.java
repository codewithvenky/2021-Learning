import java.io.File;
import java.io.IOException;
import java.util.List;

public interface Input {
	
	
 public	List<String> read() throws IOException;
 
	
	
}
