
public interface CombatState {
Warrior fight(Warrior warriorOne, Warrior WarriorTwo);
}
